param(
    [string]$url,
    [string]$zipPath,
    [string]$extractPath,
    [string]$appExe
)

try {
    Write-Host "Bắt đầu tải file zip từ"
    Invoke-WebRequest -Uri $url -OutFile $zipPath -Headers @{"User-Agent"="Mozilla/5.0"}

    if (Test-Path $extractPath) {
        Write-Host "Thư mục đích đã tồn tại"
        exit 0
    }

    Write-Host "Giải nén file zip"
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractPath -Force

    $processName = $appExe -replace ".exe", ""
    Write-Host "Tắt app cũ nếu còn chạy: $processName"
    Get-Process -Name $processName -ErrorAction SilentlyContinue | Stop-Process -Force

    $appExePath = Join-Path $extractPath $appExe
    Write-Host "Khởi động app mới: $appExePath"
    Start-Process -FilePath $appExePath

    Write-Host "Cập nhật hoàn tất!"
} catch {
    Write-Host "Lỗi trong quá trình cập nhật: $_"
    exit 1
}