param(
    [string]$url,
    [string]$zipPath,
    [string]$extractPath,
    [string]$appExe
)

try {
    Write-Host "Bắt đầu tải file zip từ"
    Invoke-WebRequest -Uri $url -OutFile $zipPath -Headers @{"User-Agent"="Mozilla/5.0"}

    if (Test-Path $extractPath) {
        Write-Host "Xóa folder cũ: $extractPath"
        Remove-Item -Path $extractPath -Recurse -Force
    }

    Write-Host "Giải nén file zip"
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractPath -Force

    try{
        $exeName = "app.exe" 
        Write-Host "Tắt app cũ nếu còn chạy: $exeName"
        Get-Process | Where-Object { $_.Path -and $_.Path.EndsWith($exeName) } | Stop-Process -Force
    } catch {
        Write-Host "Không tìm thấy app cũ hoặc không thể tắt nó."
    }
    
    $appExePath = Join-Path $extractPath $appExe
    Write-Host "Khởi động app mới: $appExePath"
    Start-Process -FilePath $appExePath

    Write-Host "Cập nhật hoàn tất!"
} catch {
    Write-Host "Lỗi trong quá trình cập nhật: $_"
    exit 1
}